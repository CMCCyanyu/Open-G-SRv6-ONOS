// Copyright 2017-present Open Networking Foundation
// SPDX-License-Identifier: LicenseRef-ONF-Member-Only-1.0

package org.stratumproject.fabric.tna.behaviour;

import com.google.common.collect.ImmutableMap;
import org.onosproject.net.PortNumber;
import org.onosproject.net.flow.DefaultTrafficTreatment;
import org.onosproject.net.flow.TrafficTreatment;
import org.onosproject.net.flow.instructions.Instruction;
import org.onosproject.net.flow.instructions.Instructions.OutputInstruction;
import org.onosproject.net.flow.instructions.L2ModificationInstruction;
import org.onosproject.net.flow.instructions.L2ModificationInstruction.ModEtherInstruction;
import org.onosproject.net.flow.instructions.L2ModificationInstruction.ModMplsLabelInstruction;
import org.onosproject.net.flow.instructions.L2ModificationInstruction.ModVlanIdInstruction;
import static org.onosproject.net.flow.instructions.L3ModificationInstruction.L3SubType.SRV6_SID_LIST;
import static org.onosproject.net.flow.instructions.L3ModificationInstruction.L3SubType.SRV6_SRH_PUSH;
import org.onosproject.net.flow.instructions.L3ModificationInstruction.ModSrv6HeaderInstruction;
import org.onosproject.net.flow.instructions.L3ModificationInstruction.ModSrv6SidListInstruction;
import org.onosproject.net.flow.instructions.L3ModificationInstruction.ModIPInstruction;
import static org.onosproject.net.flow.instructions.L3ModificationInstruction.L3SubType.IPV6_DST;

import java.util.Collection;
import com.google.common.collect.Lists;

import org.onosproject.net.pi.model.PiActionId;
import org.onosproject.net.pi.model.PiActionParamId;
import org.onosproject.net.pi.model.PiPipelineInterpreter.PiInterpreterException;
import org.onosproject.net.pi.model.PiTableId;
import org.onosproject.net.pi.runtime.PiAction;
import org.onosproject.net.pi.runtime.PiActionParam;
import org.slf4j.Logger;


import static org.slf4j.LoggerFactory.getLogger;

import java.util.List;
import java.util.stream.Collectors;

import static java.lang.String.format;
import static org.onosproject.net.flow.instructions.Instruction.Type.OUTPUT;
import static org.onosproject.net.flow.instructions.L2ModificationInstruction.L2SubType.*;
import static org.stratumproject.fabric.tna.behaviour.FabricUtils.*;

/**
 * Treatment translation logic.
 */
final class FabricTreatmentInterpreter {
    private static final Logger log = getLogger(FabricTreatmentInterpreter.class);
    private final FabricCapabilities capabilities;
    private static final ImmutableMap<PiTableId, PiActionId> NOP_ACTIONS =
            ImmutableMap.<PiTableId, PiActionId>builder()
                    .put(P4InfoConstants.FABRIC_INGRESS_FILTERING_INGRESS_PORT_VLAN,
                         P4InfoConstants.FABRIC_INGRESS_FILTERING_PERMIT)
                    .put(P4InfoConstants.FABRIC_INGRESS_FORWARDING_ROUTING_V4,
                         P4InfoConstants.FABRIC_INGRESS_FORWARDING_NOP_ROUTING_V4)
                    .put(P4InfoConstants.FABRIC_INGRESS_ACL_ACL,
                         P4InfoConstants.FABRIC_INGRESS_ACL_NOP_ACL)
                    .put(P4InfoConstants.FABRIC_EGRESS_EGRESS_NEXT_EGRESS_VLAN,
                         P4InfoConstants.FABRIC_EGRESS_EGRESS_NEXT_POP_VLAN)
                    .build();

    FabricTreatmentInterpreter(FabricCapabilities capabilities) {
        this.capabilities = capabilities;
    }

    static PiAction mapFilteringTreatment(TrafficTreatment treatment, PiTableId tableId)
            throws PiInterpreterException {
        log.warn("mapFilteringTreatment treatment[{}], tableId[{}]",
                 treatment.toString(), tableId.toString());
        if (!tableId.equals(P4InfoConstants.FABRIC_INGRESS_FILTERING_INGRESS_PORT_VLAN)) {
            // Mapping for other tables of the filtering block must be handled
            // in the pipeliner.
            tableException(tableId);
        }

        // VLAN_POP action is equivalent to the permit action (VLANs pop is done anyway)
        if (isNoAction(treatment) || isFilteringPopAction(treatment)) {
            // Permit action if table is ingress_port_vlan;
            return nop(tableId);
        }

        final ModVlanIdInstruction setVlanInst = (ModVlanIdInstruction) l2InstructionOrFail(
                treatment, VLAN_ID, tableId);
        return PiAction.builder()
                .withId(P4InfoConstants.FABRIC_INGRESS_FILTERING_PERMIT_WITH_INTERNAL_VLAN)
                .withParameter(new PiActionParam(
                        P4InfoConstants.VLAN_ID, setVlanInst.vlanId().toShort()))
                .build();
    }


    static PiAction mapForwardingTreatment(TrafficTreatment treatment, PiTableId tableId)
            throws PiInterpreterException {
        log.warn("mapForwardingTreatment treatment[{}], tableId[{}]",
                 treatment.toString(), tableId.toString());
        if (isNoAction(treatment)) {
            log.warn("mapForwardingTreatment nop");
           return nop(tableId);
        }

        treatmentException(
                tableId, treatment,
                "supports mapping only for empty/no-action treatments");
        return null;
    }

    static PiAction srv6ForwardingTreatment(TrafficTreatment treatment, PiTableId tableId)
            throws PiInterpreterException {
        log.info("srv6ForwardingTreatment treatment[{}], tableId[{}]",
                 treatment.toString(), tableId.toString());
        return mapNextSrv6Treatment(treatment, tableId);
    }

    static PiAction mapNextTreatment(TrafficTreatment treatment, PiTableId tableId)
            throws PiInterpreterException {
        log.warn("mapNextTreatment treatment[{}], tableId[{}]",
                 treatment.toString(), tableId.toString());
        if (tableId == P4InfoConstants.FABRIC_INGRESS_NEXT_NEXT_VLAN) {
            return mapNextVlanTreatment(treatment, tableId);
        } else if (tableId == P4InfoConstants.FABRIC_INGRESS_NEXT_HASHED) {
            return mapNextHashedOrSimpleTreatment(treatment, tableId, false);
        // TODO: add profile with simple next or remove references
        // } else if (tableId == P4InfoConstants.FABRIC_INGRESS_NEXT_SIMPLE) {
        //     return mapNextHashedOrSimpleTreatment(treatment, tableId, true);
        // TODO: re-enable support for xconnext
        // } else if (tableId == P4InfoConstants.FABRIC_INGRESS_NEXT_XCONNECT) {
            //     return mapNextXconnect(treatment, tableId);
        }
        throw new PiInterpreterException(format(
                "Treatment mapping not supported for table '%s'", tableId));
    }

    private static PiAction mapNextVlanTreatment(TrafficTreatment treatment, PiTableId tableId)
            throws PiInterpreterException {
        final List<ModVlanIdInstruction> modVlanIdInst = l2InstructionsOrFail(treatment, VLAN_ID, tableId)
                .stream().map(i -> (ModVlanIdInstruction) i).collect(Collectors.toList());
        if (modVlanIdInst.size() == 1) {
            return PiAction.builder().withId(P4InfoConstants.FABRIC_INGRESS_NEXT_SET_VLAN)
                    .withParameter(new PiActionParam(
                            P4InfoConstants.VLAN_ID,
                            modVlanIdInst.get(0).vlanId().toShort()))
                    .build();
        }
        // TODO: re-enable support for double-vlan
        // if (modVlanIdInst.size() == 2 && capabilities.supportDoubleVlanTerm()) {
        //     return PiAction.builder()
        //             .withId(P4InfoConstants.FABRIC_INGRESS_NEXT_SET_DOUBLE_VLAN)
        //             .withParameter(new PiActionParam(
        //                     P4InfoConstants.INNER_VLAN_ID,
        //                     modVlanIdInst.get(0).vlanId().toShort()))
        //             .withParameter(new PiActionParam(
        //                     P4InfoConstants.OUTER_VLAN_ID,
        //                     modVlanIdInst.get(1).vlanId().toShort()))
        //             .build();
        // }
        throw new PiInterpreterException("Too many VLAN instructions");
    }

    private static PiActionId srv6ActionIdGet(int sidSize) {
        switch (sidSize) {
            case 1:
                return P4InfoConstants.FABRIC_INGRESS_FORWARDING_SRV6_NXT_PUSH1;
            case 2:
                return P4InfoConstants.FABRIC_INGRESS_FORWARDING_SRV6_NXT_PUSH2;
            case 3:
                return P4InfoConstants.FABRIC_INGRESS_FORWARDING_SRV6_NXT_PUSH3;
            case 4:
                return P4InfoConstants.FABRIC_INGRESS_FORWARDING_SRV6_NXT_PUSH4;
            case 5:
                return P4InfoConstants.FABRIC_INGRESS_FORWARDING_SRV6_NXT_PUSH5;
            default:
                return null;
        }
    }

    private static PiActionId srv6CocActionIdGet(int siLen) {
        switch (siLen) {
            case 0:
                return P4InfoConstants.FABRIC_INGRESS_FORWARDING_SRV6_COC_NEXT0;
            case 1:
                return P4InfoConstants.FABRIC_INGRESS_FORWARDING_SRV6_COC_NEXT1;
            case 2:
                return P4InfoConstants.FABRIC_INGRESS_FORWARDING_SRV6_COC_NEXT2;
            case 3:
                return P4InfoConstants.FABRIC_INGRESS_FORWARDING_SRV6_COC_NEXT3;
            default:
                return null;
        }
    }

    private static PiAction mapSrv6TunnelHeadTreatment(
            TrafficTreatment treatment, PiTableId tableId)
            throws PiInterpreterException {

        log.warn("mapSrv6TunnelHeadTreatment treatment[{}], tableId[{}]",
                 treatment.toString(), tableId.toString());

        final ModSrv6SidListInstruction sidlist =
                (ModSrv6SidListInstruction) l3Instruction(treatment, SRV6_SID_LIST);
        final PiAction.Builder actionBuilder = PiAction.builder();

        Collection<PiActionParam> actionParams = Lists.newArrayList();

        for (int i = 0; i < sidlist.sids().size(); i++) {
            PiActionParamId paramId = PiActionParamId.of("s" + (i + 1));
            PiActionParam param = new PiActionParam(paramId, sidlist.sids().get(i).toOctets());
            actionParams.add(param);
        }

        if (sidlist.sids().size() > 0) {
            log.warn("mapNextSrv6Treatment treatment[{}] tableId[{}] actionParams[{}]",
                     treatment.toString(), tableId.toString(), actionParams.toString());
            actionBuilder
                    .withParameters(actionParams);
            return actionBuilder
                    .withId(srv6ActionIdGet(sidlist.sids().size()))
                    .build();
        } else {
            treatmentException(
                    tableId, treatment,
                    "srlist of tunnel is empty");
            return null;
        }
    }

    private static PiAction mapSrv6RouteTeatment(
            TrafficTreatment treatment, PiTableId tableId)
            throws PiInterpreterException {

        log.warn("mapSrv6RouteTeatment treatment[{}], tableId[{}]",
                 treatment.toString(), tableId.toString());
        final PiAction.Builder actionBuilder = PiAction.builder();

        return actionBuilder
                .withId(P4InfoConstants.FABRIC_INGRESS_FORWARDING_SRV6_TRANST)
                .build();
        }


    private static PiAction mapSrv6CocRouteTeatment(
            TrafficTreatment treatment, PiTableId tableId)
            throws PiInterpreterException {
        log.warn("mapSrv6CocRouteTeatment treatment[{}], tableId[{}]",
                 treatment.toString(), tableId.toString());

        final ModIPInstruction sidv6 =
                (ModIPInstruction) l3Instruction(treatment, IPV6_DST);
        byte[] addrArry = sidv6.ip().getIp6Address().toOctets();
        byte si = addrArry[addrArry.length - 1];

        final PiAction.Builder actionBuilder = PiAction.builder();
        return actionBuilder
                .withId(srv6CocActionIdGet(si))
                .build();
    }



    private static PiAction mapNextSrv6Treatment(
            TrafficTreatment treatment, PiTableId tableId)
            throws PiInterpreterException {

        log.warn("mapNextSrv6Treatment treatment[{}], tableId[{}]",
                 treatment.toString(), tableId.toString());

        final ModSrv6HeaderInstruction srv6Push =
                (ModSrv6HeaderInstruction) l3Instruction(treatment, SRV6_SRH_PUSH);
        final ModSrv6SidListInstruction sidlist =
                (ModSrv6SidListInstruction) l3Instruction(treatment, SRV6_SID_LIST);
        final ModIPInstruction destSid =
                (ModIPInstruction) l3Instruction(treatment, IPV6_DST);

        if (sidlist != null) {
            log.info("(sidlist.sids[{}] ", sidlist.sids().toString());
            return mapSrv6TunnelHeadTreatment(treatment, tableId);
        } else if (srv6Push != null) {
            if (destSid == null) {
                return mapSrv6RouteTeatment(treatment, tableId);
            } else {
                return mapSrv6CocRouteTeatment(treatment, tableId);
            }
        }
        treatmentException(
                tableId, treatment,
                "no support srv6 table treatment");
        return null;



    }

    private static PiAction mapNextHashedOrSimpleTreatment(
            TrafficTreatment treatment, PiTableId tableId, boolean simple)
            throws PiInterpreterException {
        // Provide mapping for output_hashed, routing_hashed, and
        // mpls_routing_hashed. multicast_hashed can only be invoked with
        // PiAction, hence no mapping. outPort required for all actions. Presence
        // of other instructions will determine which action to map to.
        log.warn("mapNextHashedOrSimpleTreatment treatment[{}], tableId[{}]",
                 treatment.toString(), tableId.toString());


        final ModEtherInstruction ethDst = (ModEtherInstruction) l2Instruction(
                treatment, ETH_DST);
        final ModEtherInstruction ethSrc = (ModEtherInstruction) l2Instruction(
                treatment, ETH_SRC);

        log.warn("mapNextHashedOrSimpleTreatment go on ");

        final PortNumber outPort = ((OutputInstruction) instructionOrFail(
                treatment, OUTPUT, tableId)).port();
        final Instruction mplsPush = l2Instruction(
                treatment, MPLS_PUSH);
        final ModMplsLabelInstruction mplsLabel = (ModMplsLabelInstruction) l2Instruction(
                treatment, MPLS_LABEL);

        final PiAction.Builder actionBuilder = PiAction.builder()
                .withParameter(new PiActionParam(P4InfoConstants.PORT_NUM, outPort.toLong()));

        if (ethDst != null && ethSrc != null) {
            actionBuilder.withParameter(new PiActionParam(
                    P4InfoConstants.SMAC, ethSrc.mac().toBytes()));
            actionBuilder.withParameter(new PiActionParam(
                    P4InfoConstants.DMAC, ethDst.mac().toBytes()));
            if (mplsLabel != null) {
                // mpls_routing_hashed
                return actionBuilder
                        .withParameter(new PiActionParam(P4InfoConstants.LABEL, mplsLabel.label().toInt()))
                        .withId(P4InfoConstants.FABRIC_INGRESS_NEXT_MPLS_ROUTING_HASHED)
                        // TODO: add profile with simple next or remove references
                        // .withId(simple ? P4InfoConstants.FABRIC_INGRESS_NEXT_MPLS_ROUTING_SIMPLE
                        //                 : P4InfoConstants.FABRIC_INGRESS_NEXT_MPLS_ROUTING_HASHED)
                        .build();
            } else {
                // routing_hashed
                return actionBuilder
                        .withId(P4InfoConstants.FABRIC_INGRESS_NEXT_ROUTING_HASHED)
                        // TODO: add profile with simple next or remove references
                        // .withId(simple ? P4InfoConstants.FABRIC_INGRESS_NEXT_ROUTING_SIMPLE
                        //                 : P4InfoConstants.FABRIC_INGRESS_NEXT_ROUTING_HASHED)
                        .build();
            }
        } else {
            // output_hashed
            return actionBuilder
                    .withId(P4InfoConstants.FABRIC_INGRESS_NEXT_OUTPUT_HASHED)
                    // TODO: add profile with simple next or remove references
                    // .withId(simple ? P4InfoConstants.FABRIC_INGRESS_NEXT_OUTPUT_SIMPLE
                    //                 : P4InfoConstants.FABRIC_INGRESS_NEXT_OUTPUT_HASHED)
                    .build();
        }
    }

    // TODO: re-enable support for xconnext
    // private static PiAction mapNextXconnect(
    //         TrafficTreatment treatment, PiTableId tableId)
    //         throws PiInterpreterException {
    //     final PortNumber outPort = ((OutputInstruction) instructionOrFail(
    //             treatment, OUTPUT, tableId)).port();
    //     return PiAction.builder()
    //             .withId(P4InfoConstants.FABRIC_INGRESS_NEXT_OUTPUT_XCONNECT)
    //             .withParameter(new PiActionParam(
    //                     P4InfoConstants.PORT_NUM, outPort.toLong()))
    //             .build();
    // }

    static PiAction mapAclTreatment(TrafficTreatment treatment, PiTableId tableId)
            throws PiInterpreterException {
        log.warn("mapAclTreatment treatment[{}], tableId[{}]",
                 treatment.toString(), tableId.toString());
        if (isNoAction(treatment)) {
            return nop(tableId);
        }
        treatmentException(
                tableId, treatment,
                "unsupported treatment");

        // This function will never return null
        return null;
    }


    static PiAction mapEgressNextTreatment(
            TrafficTreatment treatment, PiTableId tableId)
            throws PiInterpreterException {
        log.warn("mapEgressNextTreatment treatment[{}], tableId[{}]",
                 treatment.toString(), tableId.toString());
        l2InstructionOrFail(treatment, VLAN_POP, tableId);
        return PiAction.builder()
                .withId(P4InfoConstants.FABRIC_EGRESS_EGRESS_NEXT_POP_VLAN)
                .build();

    }

    private static PiAction nop(PiTableId tableId) throws PiInterpreterException {
        if (!NOP_ACTIONS.containsKey(tableId)) {
            throw new PiInterpreterException(format("table '%s' doe not specify a nop action", tableId));
        }
        return PiAction.builder().withId(NOP_ACTIONS.get(tableId)).build();
    }

    private static boolean isNoAction(TrafficTreatment treatment) {
        return treatment.equals(DefaultTrafficTreatment.emptyTreatment()) ||
                treatment.allInstructions().isEmpty();
    }

    private static boolean isFilteringPopAction(TrafficTreatment treatment) {
        return l2Instruction(treatment, VLAN_POP) != null;
    }

    private static Instruction l2InstructionOrFail(
            TrafficTreatment treatment,
            L2ModificationInstruction.L2SubType subType, PiTableId tableId)
            throws PiInterpreterException {
        final Instruction inst = l2Instruction(treatment, subType);
        if (inst == null) {
            treatmentException(tableId, treatment, format("missing %s instruction", subType));
        }
        return inst;
    }

    private static List<L2ModificationInstruction> l2InstructionsOrFail(
            TrafficTreatment treatment,
            L2ModificationInstruction.L2SubType subType, PiTableId tableId)
            throws PiInterpreterException {
        final List<L2ModificationInstruction> inst = l2Instructions(treatment, subType);
        if (inst == null || inst.isEmpty()) {
            treatmentException(tableId, treatment, format("missing %s instruction", subType));
        }
        return inst;
    }

    private static Instruction instructionOrFail(
            TrafficTreatment treatment, Instruction.Type type, PiTableId tableId)
            throws PiInterpreterException {
        final Instruction inst = instruction(treatment, type);
        if (inst == null) {
            treatmentException(tableId, treatment, format("missing %s instruction", type));
        }
        return inst;
    }

    private static void tableException(PiTableId tableId)
            throws PiInterpreterException {
        throw new PiInterpreterException(format("Table '%s' not supported", tableId));
    }

    private static void treatmentException(
            PiTableId tableId, TrafficTreatment treatment, String explanation)
            throws PiInterpreterException {
        throw new PiInterpreterException(format(
                "Invalid treatment for table '%s', %s: %s", tableId, explanation, treatment));
    }
}
