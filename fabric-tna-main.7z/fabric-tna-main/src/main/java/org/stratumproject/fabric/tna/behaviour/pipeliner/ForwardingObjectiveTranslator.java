// Copyright 2017-present Open Networking Foundation
// SPDX-License-Identifier: LicenseRef-ONF-Member-Only-1.0

package org.stratumproject.fabric.tna.behaviour.pipeliner;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import org.onlab.packet.MacAddress;
import org.onosproject.net.DeviceId;
import org.onosproject.net.PortNumber;
import org.onosproject.net.flow.DefaultTrafficSelector;
import org.onosproject.net.flow.DefaultTrafficTreatment;
import org.onosproject.net.flow.FlowRule;
import org.onosproject.net.flow.TrafficSelector;
import org.onosproject.net.flow.TrafficTreatment;
import org.onosproject.net.flow.criteria.Criterion;
import org.onosproject.net.flow.criteria.EthCriterion;
import org.onosproject.net.flow.criteria.IPCriterion;
import org.onosproject.net.flow.criteria.IPv6ExthdrFlagsCriterion;
import org.onosproject.net.flow.criteria.MplsCriterion;
import org.onosproject.net.flow.criteria.VlanIdCriterion;
import org.onosproject.net.flow.instructions.L3ModificationInstruction;
import org.onosproject.net.flowobjective.ForwardingObjective;
import org.onosproject.net.flowobjective.ObjectiveError;
import org.onosproject.net.pi.model.PiActionId;
import org.onosproject.net.pi.model.PiTableId;
import org.onosproject.net.pi.runtime.PiAction;
import org.onosproject.net.pi.runtime.PiActionParam;
import org.stratumproject.fabric.tna.behaviour.FabricCapabilities;
import org.stratumproject.fabric.tna.behaviour.P4InfoConstants;

import static org.onosproject.net.flow.instructions.L3ModificationInstruction.L3SubType.IPV6_DST;
import static org.onosproject.net.flow.instructions.L3ModificationInstruction.L3SubType.SRV6_SID_LIST;
import org.onosproject.net.flow.instructions.L3ModificationInstruction.ModSrv6SidListInstruction;
import static org.stratumproject.fabric.tna.behaviour.FabricUtils.*;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static java.lang.String.format;
import static org.stratumproject.fabric.tna.behaviour.FabricUtils.criterionNotNull;
import static org.stratumproject.fabric.tna.behaviour.FabricUtils.outputPort;

/**
 * ObjectiveTranslator implementation ForwardingObjective.
 */
class ForwardingObjectiveTranslator
        extends AbstractObjectiveTranslator<ForwardingObjective> {

    //FIXME: Max number supported by PI
    static final int CLONE_TO_CPU_ID = 511;

    private static final Set<Criterion.Type> ACL_CRITERIA = ImmutableSet.of(
            Criterion.Type.IN_PORT,
            Criterion.Type.IN_PHY_PORT,
            Criterion.Type.ETH_DST,
            Criterion.Type.ETH_DST_MASKED,
            Criterion.Type.ETH_SRC,
            Criterion.Type.ETH_SRC_MASKED,
            Criterion.Type.ETH_TYPE,
            Criterion.Type.VLAN_VID,
            Criterion.Type.IP_PROTO,
            Criterion.Type.IPV4_SRC,
            Criterion.Type.IPV4_DST,
            Criterion.Type.TCP_SRC,
            Criterion.Type.TCP_SRC_MASKED,
            Criterion.Type.TCP_DST,
            Criterion.Type.TCP_DST_MASKED,
            Criterion.Type.UDP_SRC,
            Criterion.Type.UDP_SRC_MASKED,
            Criterion.Type.UDP_DST,
            Criterion.Type.UDP_DST_MASKED,
            Criterion.Type.ICMPV4_TYPE,
            Criterion.Type.ICMPV4_CODE,
            Criterion.Type.PROTOCOL_INDEPENDENT);

    private static final Map<PiTableId, PiActionId> NEXT_ID_ACTIONS = ImmutableMap.<PiTableId, PiActionId>builder()
            .put(P4InfoConstants.FABRIC_INGRESS_FORWARDING_BRIDGING,
                 P4InfoConstants.FABRIC_INGRESS_FORWARDING_SET_NEXT_ID_BRIDGING)
            .put(P4InfoConstants.FABRIC_INGRESS_FORWARDING_ROUTING_V4,
                 P4InfoConstants.FABRIC_INGRESS_FORWARDING_SET_NEXT_ID_ROUTING_V4)
            .put(P4InfoConstants.FABRIC_INGRESS_FORWARDING_ROUTING_V6,
                 P4InfoConstants.FABRIC_INGRESS_FORWARDING_SET_NEXT_ID_ROUTING_V6)
            .put(P4InfoConstants.FABRIC_INGRESS_FORWARDING_MPLS,
                 P4InfoConstants.FABRIC_INGRESS_FORWARDING_POP_MPLS_AND_NEXT)
            .build();

    ForwardingObjectiveTranslator(DeviceId deviceId, FabricCapabilities capabilities) {
        super(deviceId, capabilities);
    }

    @Override
    public ObjectiveTranslation doTranslate(ForwardingObjective obj)
            throws FabricPipelinerException {
        final ObjectiveTranslation.Builder resultBuilder =
                ObjectiveTranslation.builder();
        log.debug("doTranslate obj[{}]", obj.toString());

        switch (obj.flag()) {
            case SPECIFIC:
                processSpecificFwd(obj, resultBuilder);
                break;
            case VERSATILE:
                processVersatileFwd(obj, resultBuilder);
                break;
            case EGRESS:
            default:

                log.warn("Unsupported ForwardingObjective type '{}'", obj.flag());
                return ObjectiveTranslation.ofError(ObjectiveError.UNSUPPORTED);
        }
        return resultBuilder.build();
    }

    private void processVersatileFwd(ForwardingObjective obj,
                                     ObjectiveTranslation.Builder resultBuilder)
            throws FabricPipelinerException {

        final Set<Criterion.Type> unsupportedCriteria = obj.selector().criteria()
                .stream()
                .map(Criterion::type)
                .filter(t -> !ACL_CRITERIA.contains(t))
                .collect(Collectors.toSet());

        if (!unsupportedCriteria.isEmpty()) {
            throw new FabricPipelinerException(format(
                    "unsupported ACL criteria %s", unsupportedCriteria.toString()));
        }

        aclRule(obj, resultBuilder);
    }

    private void processSpecificFwd(ForwardingObjective obj,
                                    ObjectiveTranslation.Builder resultBuilder)
            throws FabricPipelinerException {

        final Set<Criterion> criteriaWithMeta = Sets.newHashSet(obj.selector().criteria());
        log.debug("processSpecificFwd obj[{}]", obj.toString());

        // FIXME: Is this really needed? Meta is such an ambiguous field...
        // Why would we match on a META field?
        if (obj.meta() != null) {
            criteriaWithMeta.addAll(obj.meta().criteria());
        }

        final ForwardingFunctionType fft = ForwardingFunctionType.getForwardingFunctionType(obj);
        log.info("processSpecificFwd obj[{}] resultBuilder[{}]  fft[{}]",
                 obj.toString(), resultBuilder.toString(), fft.toString());
        switch (fft.type()) {
            case UNKNOWN:
                throw new FabricPipelinerException(
                        "unable to detect forwarding function type");
            case L2_UNICAST:
                bridgingRule(obj, criteriaWithMeta, resultBuilder, false);
                break;
            case L2_BROADCAST:
                bridgingRule(obj, criteriaWithMeta, resultBuilder, true);
                break;
            case IPV4_ROUTING:
            case IPV4_ROUTING_MULTICAST:
                ipv4RoutingRule(obj, criteriaWithMeta, resultBuilder);
                break;
            case MPLS_SEGMENT_ROUTING:
                mplsRule(obj, criteriaWithMeta, resultBuilder);
                break;
            case SRV6_ROUTING:
            case SRV6_ROUTING_COC0:
            case SRV6_ROUTING_COC1:
            case SRV6_ROUTING_COC2:
            case SRV6_ROUTING_COC3:
                srv6Rule(obj, criteriaWithMeta, resultBuilder);
                break;
            case IPV6_ROUTING:
            case IPV6_ROUTING_MULTICAST:
                ipv6RoutingRule(obj, criteriaWithMeta, resultBuilder);
                break;

            default:
                throw new FabricPipelinerException(format(
                        "unsupported forwarding function type '%s'",
                        fft));
        }
    }

    private void bridgingRule(ForwardingObjective obj, Set<Criterion> criteriaWithMeta,
                              ObjectiveTranslation.Builder resultBuilder,
                              boolean broadcast)
            throws FabricPipelinerException {

        final VlanIdCriterion vlanIdCriterion = (VlanIdCriterion) criterionNotNull(
                criteriaWithMeta, Criterion.Type.VLAN_VID);
        final TrafficSelector.Builder selector = DefaultTrafficSelector.builder()
                .add(vlanIdCriterion);

        if (!broadcast) {
            final EthCriterion ethDstCriterion = (EthCriterion) criterionNotNull(
                    obj.selector(), Criterion.Type.ETH_DST);
            selector.matchEthDstMasked(ethDstCriterion.mac(), MacAddress.EXACT_MASK);
        }

        resultBuilder.addFlowRule(flowRule(
                obj, P4InfoConstants.FABRIC_INGRESS_FORWARDING_BRIDGING, selector.build()));
    }

    private void ipv4RoutingRule(ForwardingObjective obj, Set<Criterion> criteriaWithMeta,
                                 ObjectiveTranslation.Builder resultBuilder)
            throws FabricPipelinerException {
        final IPCriterion ipDstCriterion = (IPCriterion) criterionNotNull(
                criteriaWithMeta, Criterion.Type.IPV4_DST);

        if (ipDstCriterion.ip().prefixLength() == 0) {
            defaultIpv4Route(obj, resultBuilder);
            return;
        }

        final TrafficSelector selector = DefaultTrafficSelector.builder()
                .add(ipDstCriterion)
                .build();

        resultBuilder.addFlowRule(flowRule(
                obj, P4InfoConstants.FABRIC_INGRESS_FORWARDING_ROUTING_V4, selector));
    }

    private void defaultIpv4Route(ForwardingObjective obj,
                                  ObjectiveTranslation.Builder resultBuilder)
            throws FabricPipelinerException {
        ForwardingObjective defaultObj = obj.copy()
                .withPriority(0)
                .add();
        final TrafficSelector selector = DefaultTrafficSelector.emptySelector();
        resultBuilder.addFlowRule(flowRule(
                defaultObj, P4InfoConstants.FABRIC_INGRESS_FORWARDING_ROUTING_V4, selector));
    }

    private void mplsRule(ForwardingObjective obj, Set<Criterion> criteriaWithMeta,
                          ObjectiveTranslation.Builder resultBuilder)
            throws FabricPipelinerException {

        final MplsCriterion mplsCriterion = (MplsCriterion) criterionNotNull(
                criteriaWithMeta, Criterion.Type.MPLS_LABEL);
        final TrafficSelector selector = DefaultTrafficSelector.builder()
                .add(mplsCriterion)
                .build();

        resultBuilder.addFlowRule(flowRule(
                obj, P4InfoConstants.FABRIC_INGRESS_FORWARDING_MPLS, selector));
    }

    private void defaultIpv6Route(ForwardingObjective obj,
                                  ObjectiveTranslation.Builder resultBuilder)
            throws FabricPipelinerException {
        ForwardingObjective defaultObj = obj.copy()
                .withPriority(0)
                .add();
        final TrafficSelector selector = DefaultTrafficSelector.emptySelector();
        resultBuilder.addFlowRule(flowRule(
                defaultObj, P4InfoConstants.FABRIC_INGRESS_FORWARDING_ROUTING_V6, selector));
    }

    private void ipv6RoutingRule(ForwardingObjective obj, Set<Criterion> criteriaWithMeta,
                                 ObjectiveTranslation.Builder resultBuilder)
            throws FabricPipelinerException {
        final IPCriterion ipDstCriterion = (IPCriterion) criterionNotNull(
                criteriaWithMeta, Criterion.Type.IPV6_DST);

        log.debug("ipv6RoutingRule obj[{}]", obj.toString());

        if (ipDstCriterion.ip().prefixLength() == 0) {
            defaultIpv6Route(obj, resultBuilder);
            return;
        }

        final TrafficSelector selector = DefaultTrafficSelector.builder()
                .add(ipDstCriterion)
                .build();

        resultBuilder.addFlowRule(flowRule(
                obj, P4InfoConstants.FABRIC_INGRESS_FORWARDING_ROUTING_V6, selector));
    }


    //zsc modify
    private void srv6TransRule(ForwardingObjective obj, Set<Criterion> criteriaWithMeta,
                          ObjectiveTranslation.Builder resultBuilder)
            throws FabricPipelinerException {
        log.info("srv6TransRule srv6Rule obj[{}] resultBuilder[{}]",
                 obj.toString(), resultBuilder.toString());
        final IPCriterion ipDstCriterion = (IPCriterion) criterionNotNull(
                criteriaWithMeta, Criterion.Type.SRV6_DST_SID);
        final IPv6ExthdrFlagsCriterion extHdrCriterion = (IPv6ExthdrFlagsCriterion) criterion(
                criteriaWithMeta, Criterion.Type.IPV6_EXTHDR);
        final L3ModificationInstruction.ModIPInstruction destSid =
                (L3ModificationInstruction.ModIPInstruction) l3Instruction(obj.treatment(), IPV6_DST);


        if (ipDstCriterion.ip().prefixLength() == 0) {
            log.info("ipDstCriterion prefixLength");
            return;
        }
        if (null == destSid) {
            log.info("srv6TransRule destSid null");
            final TrafficSelector select = DefaultTrafficSelector.builder()
                    .add(ipDstCriterion)
                    .build();
            resultBuilder.addFlowRule(flowRule(
                    obj, P4InfoConstants.FABRIC_INGRESS_FORWARDING_SRV6, select));
        } else {
            log.info("srv6TransRule destSid [{}]", destSid.toString());
            final TrafficSelector select = DefaultTrafficSelector.builder()
                    .add(ipDstCriterion)
                    .add(extHdrCriterion)
                    .build();
            resultBuilder.addFlowRule(flowRule(
                    obj, P4InfoConstants.FABRIC_INGRESS_FORWARDING_SRV6COC, select));

        }
    }


    private void srv6Rule(ForwardingObjective obj, Set<Criterion> criteriaWithMeta,
                          ObjectiveTranslation.Builder resultBuilder)
            throws FabricPipelinerException {
        log.warn("ForwardingObjectiveTranslator srv6Rule obj[{}] resultBuilder[{}]",
                 obj.toString(), resultBuilder.toString());
        final IPCriterion ipDstCriterion = (IPCriterion) criterionNotNull(
                criteriaWithMeta, Criterion.Type.SRV6_DST_SID);

        if (ipDstCriterion.ip().prefixLength() == 0) {
            return;
        }
        //with no srlist
        final ModSrv6SidListInstruction sidlist =
                (ModSrv6SidListInstruction) l3Instruction(obj.treatment(), SRV6_SID_LIST);
        if (sidlist == null) {
            srv6TransRule(obj, criteriaWithMeta, resultBuilder);
            return;
        }

        final TrafficSelector selector = DefaultTrafficSelector.builder()
                .add(ipDstCriterion)
                .build();

        resultBuilder.addFlowRule(flowRule(
                obj, P4InfoConstants.FABRIC_INGRESS_FORWARDING_SRV6, selector));
    }

    private void aclRule(ForwardingObjective obj,
                         ObjectiveTranslation.Builder resultBuilder)
            throws FabricPipelinerException {
        if (obj.nextId() == null && obj.treatment() != null) {
            final TrafficTreatment treatment = obj.treatment();
            final PortNumber outPort = outputPort(treatment);
            if (outPort != null
                    && outPort.equals(PortNumber.CONTROLLER)
                    && treatment.allInstructions().size() == 1) {

                final PiAction aclAction;
                if (treatment.clearedDeferred()) {
                    aclAction = PiAction.builder()
                            .withId(P4InfoConstants.FABRIC_INGRESS_ACL_PUNT_TO_CPU)
                            .build();
                } else {
                    // Action is COPY_TO_CPU
                    aclAction = PiAction.builder()
                            .withId(P4InfoConstants.FABRIC_INGRESS_ACL_COPY_TO_CPU)
                            .build();
                }
                final TrafficTreatment piTreatment = DefaultTrafficTreatment.builder()
                        .piTableAction(aclAction)
                        .build();
                resultBuilder.addFlowRule(flowRule(
                        obj, P4InfoConstants.FABRIC_INGRESS_ACL_ACL, obj.selector(), piTreatment));
                return;
            }
        }
        resultBuilder.addFlowRule(flowRule(
                obj, P4InfoConstants.FABRIC_INGRESS_ACL_ACL, obj.selector()));
    }

    private FlowRule flowRule(
            ForwardingObjective obj, PiTableId tableId, TrafficSelector selector)
            throws FabricPipelinerException {
        return flowRule(obj, tableId, selector, nextIdOrTreatment(obj, tableId));
    }

    private static TrafficTreatment nextIdOrTreatment(
            ForwardingObjective obj, PiTableId tableId)
            throws FabricPipelinerException {
        if (obj.nextId() == null) {
            return obj.treatment();
        } else {
            if (!NEXT_ID_ACTIONS.containsKey(tableId)) {
                throw new FabricPipelinerException(format(
                        "BUG? no next_id action set for table %s", tableId));
            }
            return DefaultTrafficTreatment.builder()
                    .piTableAction(
                            setNextIdAction(obj.nextId(),
                                            NEXT_ID_ACTIONS.get(tableId)))
                    .build();
        }
    }

    private static PiAction setNextIdAction(Integer nextId, PiActionId actionId) {
        final PiActionParam nextIdParam = new PiActionParam(P4InfoConstants.NEXT_ID, nextId);
        return PiAction.builder()
                .withId(actionId)
                .withParameter(nextIdParam)
                .build();
    }
}
