/*
 * Copyright 2015-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.onosproject.srv6.web;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.onosproject.codec.CodecContext;
import org.onosproject.codec.JsonCodec;
import org.onosproject.srv6.DefaultSrv6Tunnel;
import org.onosproject.srv6.Srv6Tunnel;
import org.onlab.packet.Ip6Address;

import java.util.ArrayList;
import java.util.List;

/**
 * Codec of Tunnel class.
 */
public final class Srv6Codec extends JsonCodec<Srv6Tunnel> {

    // JSON field names
    private static final String TUNNEL_ID = "id";
    private static final String DEFICE_NAMEE = "deviceName";
    private static final String SID_LIST = "sids";

    @Override
    public ObjectNode encode(Srv6Tunnel tunnel, CodecContext context) {
        final ObjectNode result = context.mapper().createObjectNode()
                .put(TUNNEL_ID, tunnel.id());

        result.put(DEFICE_NAMEE, tunnel.deviceName());

        final ArrayNode jsonSids = result.putArray(SID_LIST);

        tunnel.sids().forEach(sid -> jsonSids.add(sid.toString()));

        return result;
    }

    @Override
    public DefaultSrv6Tunnel decode(ObjectNode json, CodecContext context) {

        String tid = json.path(TUNNEL_ID).asText();
        String deviceName = json.path(DEFICE_NAMEE).asText();


        List<Ip6Address> sids = new ArrayList<>();

        if (!json.path(SID_LIST).isMissingNode()) {
            ArrayNode sidList = (ArrayNode) json.path(SID_LIST);
            for (JsonNode o : sidList) {
                sids.add(Ip6Address.valueOf(o.toString()));
            }
        }
        Ip6Address dstIp = sids.get(sids.size() - 1);

        return new DefaultSrv6Tunnel(deviceName, tid, dstIp, sids);
    }

}
