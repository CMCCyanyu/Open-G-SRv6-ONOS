/*
 * Copyright 2015-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.onosproject.srv6.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import org.onosproject.rest.AbstractWebResource;
import org.onosproject.srv6.Srv6Service;
import org.onosproject.srv6.Srv6Tunnel;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.Path;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import static org.onlab.util.Tools.readTreeFromStream;

/**
 * Query, create and remove segment routing tunnels.
 */
 @Path("srv6")
public class Srv6WebResource extends AbstractWebResource {

    private static final Srv6Codec TUNNEL_CODEC = new Srv6Codec();

    /**
     * Get all segment routing tunnels.
     * Returns an array of segment routing tunnels.
     *
     * @return status of OK
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getSrv6Tunnel() {
        Srv6Service srService = get(Srv6Service.class);
        List<Srv6Tunnel> srv6Tunnels = srService.getSrv6Tunnels();
        ObjectNode result = new ObjectMapper().createObjectNode();
        result.set("srv6Tunnel", new Srv6Codec().encode(srv6Tunnels, this));

        return ok(result.toString()).build();
    }

    /**
     * Create a new segment routing tunnel.
     *
     * @param input JSON stream for tunnel to create
     * @return status of the request - OK if the tunnel is created,
     * @throws IOException if the JSON is invalid
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createSrv6Tunnel(InputStream input) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode tunnelJson = readTreeFromStream(mapper, input);
        Srv6Service srService = get(Srv6Service.class);
        Srv6Tunnel tunnelInfo = TUNNEL_CODEC.decode(tunnelJson, this);
        srService.createSrv6Tunnel(tunnelInfo);

        return Response.ok().build();
    }

    /**
     * Delete a segment routing tunnel.
     *
     * @param input JSON stream for tunnel to delete
     * @return 204 NO CONTENT, if the tunnel is removed
     * @throws IOException if JSON is invalid
     */
    @DELETE
    @Consumes(MediaType.APPLICATION_JSON)
    public Response removeSrv6Tunnel(InputStream input) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode tunnelJson = readTreeFromStream(mapper, input);
        Srv6Service srService = get(Srv6Service.class);
        Srv6Tunnel tunnelInfo = TUNNEL_CODEC.decode(tunnelJson, this);
        srService.removeSrv6Tunnel(tunnelInfo);

        return Response.noContent().build();
    }

}
