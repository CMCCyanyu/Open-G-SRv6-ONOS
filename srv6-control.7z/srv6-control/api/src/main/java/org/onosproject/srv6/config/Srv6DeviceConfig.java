/*
 * Copyright 2016-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.onosproject.srv6.config;

import org.onlab.packet.Ip6Address;
import org.onosproject.net.DeviceId;
import org.onosproject.net.config.Config;

import java.util.Optional;

/**
 * Configuration object for srv6 Application.
 */
public class Srv6DeviceConfig extends Config<DeviceId> {
    private static final String NAME = "name";
    private static final String SRV6_SID_END = "srv6SidEnd";

    @Override
    public boolean isValid() {
        return hasOnlyFields(SRV6_SID_END) &&
                name() != null &&
                (hasField(SRV6_SID_END) && srv6SidEnd() != null);
    }

    /**
     * Gets the name of the router.
     *
     * @return Optional name of the router. May be empty if not configured.
     */
    public Optional<String> name() {
        String name = get(NAME, null);
        return name != null ? Optional.of(name) : Optional.empty();
    }

    /**
     * Sets the name of the router.
     *
     * @param name name of the router.
     * @return the config of the router.
     */
    public Srv6DeviceConfig setName(String name) {
        return (Srv6DeviceConfig) setOrClear(NAME, name);
    }

    /**
     * Gets the srv6 end SID of the router.
     *
     * @return node SID of the router. Or -1 if not configured.
     */
    public Ip6Address srv6SidEnd() {
        String ip = get(SRV6_SID_END, null);
        return ip != null ? Ip6Address.valueOf(ip) : null;
    }

    /**
     * Sets the srv6 end SID of the router.
     *
     * @param sid node SID of the router.
     * @return the config of the router.
     */
    public Srv6DeviceConfig setSrv6SidEnd(String sid) {
        return (Srv6DeviceConfig) setOrClear(SRV6_SID_END, sid);
    }

}
