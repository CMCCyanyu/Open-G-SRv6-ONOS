/*
 * Copyright 2015-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.onosproject.srv6;


import org.onlab.packet.IpAddress;
import org.onosproject.core.ApplicationId;
import org.onosproject.net.DeviceId;
import org.onosproject.net.flow.DefaultTrafficTreatment;
import org.onosproject.net.flow.TrafficSelector;
import org.onosproject.net.flow.TrafficTreatment;
import org.onosproject.net.flowobjective.DefaultNextObjective;
import org.onosproject.net.flowobjective.DefaultObjectiveContext;
import org.onosproject.net.flowobjective.FlowObjectiveService;
import org.onosproject.net.flowobjective.NextObjective;
import org.onosproject.net.flowobjective.ObjectiveContext;
import org.onosproject.srv6.config.DeviceConfigNotFoundException;
import org.onosproject.srv6.config.DeviceProperties;
import org.onosproject.store.service.EventuallyConsistentMap;
import org.slf4j.Logger;


import java.util.List;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;
import static org.onlab.packet.IpAddress.Version.INET6;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Default ECMP group handler creation module. This component creates a set of
 * ECMP groups for every neighbor that this device is connected to based on
 * whether the current device is an edge device or a transit device.
 */
public class Srv6NextobjHander  {
    private static final Logger log = getLogger(Srv6NextobjHander.class);

    protected final DeviceId deviceId;
    protected final ApplicationId appId;
    protected final DeviceProperties deviceConfig;
    protected FlowObjectiveService flowObjectiveService;


    // distributed store for (device+tunnelid) mapped to next-id and neighbors
    protected EventuallyConsistentMap<Srv6NextObjectiveStoreKey, Integer>
            srv6NextobjectStore = null;
    private Srv6Manager srManager;


    protected Srv6NextobjHander(DeviceId deviceId, ApplicationId appId,
                                  DeviceProperties config,
                                  FlowObjectiveService flowObjService,
                                  Srv6Manager srManager) {
        this.deviceId = checkNotNull(deviceId);
        this.appId = checkNotNull(appId);
        this.deviceConfig = checkNotNull(config);
        this.flowObjectiveService = flowObjService;
        this.srv6NextobjectStore = checkNotNull(srManager.srv6NextObjStore());
        this.srManager = srManager;
    }

    /**
     * Gracefully shuts down a groupHandler. Typically called when the handler is
     * no longer needed.
     * @return srv6NextobjectStore obj of the decice
     */
    public EventuallyConsistentMap<Srv6NextObjectiveStoreKey, Integer> srv6NextobjectStore() {
        return srv6NextobjectStore;
    }

    /**
     * Creates a srv6tunnel next bject.
     *
     * @param id tunnnel id
     * @return default nextobj id
     */
    public int getSrv6NextObjectiveId(String id) {
        Integer nextId = srv6NextobjectStore.
                get(new Srv6NextObjectiveStoreKey(deviceId, id));

        return (nextId != null) ? nextId : -1;
    }

    /**
     * Creates a group handler object.
     *
     * @param deviceId device identifier
     * @param appId application identifier
     * @param config interface to retrieve the device properties
     * @param flowObjService flow objective service object
     * @param srManager segment routing manager
     * @throws DeviceConfigNotFoundException if the device configuration is not found
     * @return default group handler type
     */
    public static Srv6NextobjHander createNextObjHandler(
                                                         DeviceId deviceId,
                                                         ApplicationId appId,
                                                         DeviceProperties config,
                                                         FlowObjectiveService flowObjService,
                                                         Srv6Manager srManager)
                                                                 throws DeviceConfigNotFoundException {
        return new Srv6NextobjHander(deviceId, appId, config,
                                       flowObjService,
                                       srManager);
    }


    /**
     * Returns the next objective of type hashed (or simple) associated with the
     * destination set. In addition, updates the existing next-objective if new
     * route-paths found have resulted in the addition of new next-hops to a
     * particular destination. If there is no existing next objective for this
     * destination set, this method would create a next objective and return the
     * nextId. Optionally metadata can be passed in for the creation of the next
     * objective. If the parameter simple is true then a simple next objective
     * is created instead of a hashed one.
     *
     * @param srv6Tunnel destination set
     * @param meta metadata passed into the creation of a Next Objective
     * @param simple if true, a simple next objective will be created instead of
     *            a hashed next objective
     * @return int if found or -1 if there are errors in the creation of the
     *         neighbor set.
     */
    public int getNextObjectiveId(Srv6Tunnel srv6Tunnel,
                                  TrafficSelector meta, boolean simple) {
        Integer next = srv6NextobjectStore.
                get(new Srv6NextObjectiveStoreKey(deviceId, srv6Tunnel.id()));
        if (next != null) {
            return next;
        }

        log.info("getNextObjectiveId in device{}: Next objective id "
                + "not found for {} ... creating", deviceId, srv6Tunnel.id());
        createNextObjForSrv6Tunnel(srv6Tunnel, meta, simple);
        next = srv6NextobjectStore.
                get(new Srv6NextObjectiveStoreKey(deviceId, srv6Tunnel.id()));
        if (next == null) {
            log.warn("getNextObjectiveId: unable to create next objective");
            // failure in creating group
            return -1;
        } else {
            log.info("getNextObjectiveId in device{}: Next objective id {} "
                + "created for {}", deviceId, next, srv6Tunnel.id());
        }
        return next;
    }

    //创建下一跳对象
    public void createNextObjForSrv6Tunnel(Srv6Tunnel srv6Tunnel,
                                              TrafficSelector meta,
                                              boolean simple) {
        int nextId = flowObjectiveService.allocateNextId();
        NextObjective.Type type = (simple) ? NextObjective.Type.SIMPLE
                                           : NextObjective.Type.HASHED;

        NextObjective.Builder nextObjBuilder = DefaultNextObjective
                .builder()
                .withId(nextId)
                .withType(type)
                .fromApp(appId);
        if (meta != null) {
            nextObjBuilder.withMeta(meta);
        }

        List<IpAddress> sidnew = srv6Tunnel.sids().stream()
                .map(e -> IpAddress.valueOf(INET6, e.toOctets()))
                .collect(Collectors.toList());
        TrafficTreatment.Builder tBuilder = DefaultTrafficTreatment
                .builder();
        tBuilder.pushSRH().setSrv6SidList(sidnew);
        nextObjBuilder.addTreatment(tBuilder.build());

        ObjectiveContext context = new DefaultObjectiveContext(
                (objective) ->
                log.info("createNextObjForSrv6Tunnel installed "
                        + "NextObj {} on {}", nextId, deviceId),
                (objective, error) -> {
                    log.warn("createNextObjForSrv6Tunnel failed to install NextObj {} on {}: {}",
                            nextId, deviceId, error);
                });

        NextObjective nextObj = nextObjBuilder.add(context);
        log.info(".. createNextObjForSrv6Tunnel: Submitted "
                + "next objective {} in device {}", nextId, deviceId);
        flowObjectiveService.next(deviceId, nextObj);
        //update store
        srv6NextobjectStore.put(new Srv6NextObjectiveStoreKey(deviceId, srv6Tunnel.id()), nextId);
    }
 }
