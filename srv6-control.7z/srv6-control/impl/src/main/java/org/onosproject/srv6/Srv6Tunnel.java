/*
 * Copyright 2015-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.onosproject.srv6;

import org.onlab.packet.Ip6Address;
import org.onosproject.net.DeviceId;

import java.util.List;

/**
 * Interface for Segment Routing Policy.
 */
public interface Srv6Tunnel {
    /**
     * tunnel used as key.
     *@return tunnel ID
     */
    String id();

    /**
     * tunnel used as key.
     *@return deviceName
     */
    String deviceName();

    /**
     * Device to allocate the tunnel.
     * @return device ID
     */
    DeviceId deviceid();
    /**
     * tunnel destination may be srv6  or srv6 sid.
     * @return tunnel destaddr
     */
    Ip6Address dstIp();
    /**
     * tunnel srv6-list info in form of srv6.
     * @return sid list
     */
    List<Ip6Address> sids();
    /**
     * nextId info in form of srv6.
     * @return next obj id
     */
    Integer nextId();

    /**
     * Sets group ID for the tunnel.
     *
     * @param id group identifier
     */
    void setNextId(int id);

}
