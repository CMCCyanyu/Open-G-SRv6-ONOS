/*
 * Copyright 2015-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.onosproject.srv6;


import org.onlab.packet.Ip6Address;
import org.onosproject.net.DeviceId;
import org.onosproject.net.config.basics.BasicDeviceConfig;
import org.onosproject.srv6.config.DeviceConfigNotFoundException;
import org.onosproject.srv6.config.DeviceProperties;
import org.onosproject.srv6.config.Srv6DeviceConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Segment Routing configuration component that reads the
 * segment routing related configuration from Network Configuration Manager
 * component and organizes in more accessible formats.
 */
public class DeviceConfiguration implements DeviceProperties {

    private static final Logger log = LoggerFactory.getLogger(DeviceConfiguration.class);
    private final Map<DeviceId, Srv6Info> deviceConfigMap = new ConcurrentHashMap<>();
    private Srv6Manager srManager;

    private class Srv6Info {
        Ip6Address srv6SidEnd = Ip6Address.valueOf("::");
        DeviceId deviceId;


        public Srv6Info() {
        }
    }

    /**
     * Constructs device configuration for all Segment Router devices,
     * organizing the data into various maps for easier access.
     *
     * @param srManager Segment Routing Manager
     */
    public DeviceConfiguration(Srv6Manager srManager) {
        this.srManager = srManager;
        updateConfig();
    }

    public void updateConfig() {
        // Read config from device subject, excluding gatewayIps and subnets.
        Set<DeviceId> deviceSubjects =
                srManager.cfgService.getSubjects(DeviceId.class, Srv6DeviceConfig.class);
        deviceSubjects.forEach(subject -> {
            BasicDeviceConfig basicDeviceConfig = srManager.cfgService.addConfig(subject, BasicDeviceConfig.class);
            if (!basicDeviceConfig.purgeOnDisconnection()) {
                // Setting purge on disconnection flag for the device SR has control over.
                // addConfig returns a config if it exists or creates a new one.
                log.info("PurgeOnDisconnection set to true for device {}", subject);
                basicDeviceConfig.purgeOnDisconnection(true);
                srManager.cfgService.applyConfig(subject, BasicDeviceConfig.class, basicDeviceConfig.node());
            }
            Srv6DeviceConfig config =
                    srManager.cfgService.getConfig(subject, Srv6DeviceConfig.class);
            Srv6Info info = new Srv6Info();
            info.deviceId = subject;

            info.srv6SidEnd = config.srv6SidEnd();

            deviceConfigMap.put(info.deviceId, info);
            log.debug("Read device config for device: {}", info.deviceId);
        });
    }

    public Collection<DeviceId> getRouters() {
        return deviceConfigMap.keySet();
    }

    @Override
    public boolean isConfigured(DeviceId deviceId) {
        return deviceConfigMap.get(deviceId) != null;
    }

    @Override
    public Ip6Address getSrv6SidEnd(DeviceId deviceId) throws DeviceConfigNotFoundException {
        Srv6Info srinfo = deviceConfigMap.get(deviceId);
        if (srinfo != null) {
            log.trace("getSrv6SidEnd for device{} is {}", deviceId, srinfo.srv6SidEnd);
            return srinfo.srv6SidEnd;
        } else {
            String message = "getSrv6SidEnd fails for device: " + deviceId + ".";
            throw new DeviceConfigNotFoundException(message);
        }
    }

    /**
     * Returns the device identifier or data plane identifier (dpid)
     * of a segment router given its router ipv6 address.
     *
     * @param srv6SidEnd router ipv6 address
     * @return deviceId device identifier
     */
    public DeviceId getDeviceId(Ip6Address srv6SidEnd) {
        for (Map.Entry<DeviceId, Srv6Info> entry:
                deviceConfigMap.entrySet()) {
            if (entry.getValue().srv6SidEnd.equals(srv6SidEnd)) {
                return entry.getValue().deviceId;
            }
        }

        return null;
    }

}
