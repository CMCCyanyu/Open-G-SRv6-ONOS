/*
 * Copyright 2015-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.onosproject.srv6;

import com.google.common.collect.Lists;
import org.onlab.packet.Ip6Address;
import java.util.List;

import org.onlab.packet.IpPrefix;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.onlab.packet.IpAddress.INET6_BYTE_LENGTH;

public class Gsrv6Compres {
    private static final Logger log = LoggerFactory.getLogger(Gsrv6Compres.class);
    public static final int GSIDLEN16 = 16;
    public static final int GSIDLEN32 = 32;
    public static final int COC16_FLAVOR = 0x02;
    public static final int COC32_FLAVOR = 0x01;
    public static final int COC16_SI_LEN = 0x3;  /*3 bit used for SI*/
    public static final int COC32_SI_LEN = 0x2;  /*2 bit used for SI*/
    public static final int COC16_MAX_ELEMENT = 0x8;  /*G-SID container number for 16 bit*/
    public static final int COC32_MAX_ELEMENT = 0x4; /*G-SID container number for 32 bit*/


    public  List<Ip6Address> singleSegmentCompress(
            List<Ip6Address> segmentList,
            int commonPrefixLength,
            int gsidLength,
            int argLength) {
        Ip6Address commonPrefix = null;
        IpPrefix ipPrefixFirst = null;
        IpPrefix ipPrefixNext = null;
        Ip6Address addrTemp = null;
        Ip6Address addrCotainer = null;
        List<Ip6Address> singleCompressSid = Lists.newArrayList();
        int containElement = 0;
        int prefilBits = 0;
        int gsidBits = 0;
        int argBits = 0;
        byte[] addrArry = null;

        log.info("commonPrefixLength:{},gsidLength:{},argLength:{}", commonPrefixLength, gsidLength, argLength);
        log.info("single segment size:{} ", segmentList.size());

        if ((0 >= commonPrefixLength)
                || (commonPrefixLength % 8 != 0)
                || (0 > argLength)
                || ((gsidLength != GSIDLEN16) && (gsidLength != GSIDLEN32))) {
            log.error("commonPrefixLength " + commonPrefixLength +
                              "gsidLength" + gsidLength + "argLength" +
                              argLength + "in paraer error");
            return singleCompressSid;
        }

        if (((gsidLength == GSIDLEN16) && (argLength < COC16_SI_LEN))
           || ((gsidLength == GSIDLEN32) && (argLength < COC32_SI_LEN))) {
            log.error("argLength" + argLength + "in paraer error");
            return singleCompressSid;
        }

        if ((commonPrefixLength + gsidLength + argLength) != 128) {
            log.error("total error CommonPrefixLength" +
                              commonPrefixLength + "gsidLength" +
                              gsidLength + "argLength" + argLength);
            return singleCompressSid;
        }

        if (segmentList.size() <= 2) {
            singleCompressSid.addAll(segmentList);
            return singleCompressSid;
        }

        /*The first IP address can be modified to a compressed IP address*/
        prefilBits = commonPrefixLength / 8;
        gsidBits = gsidLength / 8;
        argBits = argLength / 8;
        addrTemp = segmentList.get(0);
        addrArry = addrTemp.toOctets();
        log.info("addrArry.Length:{}", addrArry.length);
        if (gsidLength == GSIDLEN32) {
            //addrArry[addrArry.length - 1] |= (byte) 0x03;
           // addrArry[addrArry.length - 1 - argBits] |= (byte) COC32_FLAVOR;
            addrArry[prefilBits + gsidBits - 1] |= (byte) COC32_FLAVOR;
        } else {
            //addrArry[addrArry.length - 1] |= (byte) 0x07;
            //addrArry[addrArry.length - 1 - argBits] |= (byte) COC16_FLAVOR;
            addrArry[prefilBits + gsidBits - 1] |= (byte) COC16_FLAVOR;
        }
        addrCotainer = Ip6Address.valueOf(addrArry);
        singleCompressSid.add(addrCotainer);

        /*Check whether the compression condition with the same prefix and all Arg bits is 0*/
        ipPrefixFirst = IpPrefix.valueOf(addrTemp, commonPrefixLength);
        containElement = 0;
        addrArry = new byte[INET6_BYTE_LENGTH];
        for (int sidIndex = 1; sidIndex < segmentList.size(); sidIndex++) {
            addrTemp = segmentList.get(sidIndex);
            byte[] tmpAddrArry = addrTemp.toOctets();
            ipPrefixNext = IpPrefix.valueOf(addrTemp, commonPrefixLength);
            if (!ipPrefixNext.equals(ipPrefixFirst)) {
                log.info("prefix not equal");
            }
            if (gsidLength == GSIDLEN32) {
                for (int gsidIndex = 0; gsidIndex < gsidBits; gsidIndex++) {
                    addrArry[containElement * gsidBits + gsidIndex] =  tmpAddrArry[prefilBits + gsidIndex];
                }
                containElement++;
                if (sidIndex != segmentList.size() - 1) {
                    addrArry[containElement * gsidBits - 1] |= (byte) COC32_FLAVOR;
                }
                if ((containElement >= COC32_MAX_ELEMENT)
                        || (sidIndex == segmentList.size() - 1)) {
                    addrCotainer = Ip6Address.valueOf(addrArry);
                    singleCompressSid.add(addrCotainer);
                    addrArry = new byte[INET6_BYTE_LENGTH];
                    containElement = 0;

                }
            } else {
                for (int gsidIndex = 0; gsidIndex < gsidBits; gsidIndex++) {
                    addrArry[containElement * gsidBits + gsidIndex] =  tmpAddrArry[prefilBits + gsidIndex];
                }
                containElement++;
                if (sidIndex != segmentList.size() - 1) {
                    addrArry[containElement * gsidBits - 1] |= (byte) COC16_FLAVOR;
                }
                if ((containElement >= COC16_MAX_ELEMENT) || (sidIndex == segmentList.size() - 1)) {
                    addrCotainer = Ip6Address.valueOf(addrArry);
                    singleCompressSid.add(addrCotainer);
                    containElement = 0;
                    addrArry = new byte[INET6_BYTE_LENGTH];
                }
            }
        }
        log.info("singleCompressSid length:{}", singleCompressSid.size());
        return singleCompressSid;
    }

    public Ip6Address addrToSid(Ip6Address nodeAddr) {
        Ip6Address nodeSid = Ip6Address.valueOf(nodeAddr.toOctets());
        return nodeSid;
    }

    public boolean nodeGSrv6Ability(Ip6Address nodeAddr) {
        return true;
    }

    public int compressPerfixLenGet(Ip6Address nodeAddr) {
        int commonPrefixLength = 32;
        return commonPrefixLength;
    }

    public int compressGsidLenGet(Ip6Address nodeAddr) {
        int gsidLength = 32;
        return gsidLength;
    }

    public int compressArgLenGet(Ip6Address nodeAddr) {
        int argLength = 64;
        return argLength;
    }

    public boolean gsidPerfixMatch(Ip6Address gsidFirst, Ip6Address gsidNext,
                                    int commonPrefixLength) {
        IpPrefix ipPrefixFirst = null;
        IpPrefix ipPrefixNext = null;

        ipPrefixFirst = IpPrefix.valueOf(gsidFirst, commonPrefixLength);
        ipPrefixNext = IpPrefix.valueOf(gsidNext, commonPrefixLength);
        return ipPrefixFirst.equals(ipPrefixNext);
    }

    public List<Ip6Address> gSrv6Compress(List<Ip6Address> segmentList,
                                           boolean isSid) {
        List<Ip6Address> sidListSrc = null;
        List<Ip6Address> gsidList = Lists.newArrayList();
        List<Ip6Address> singleSegment = null;
        List<Ip6Address> singleCompressSegment = null;
        Ip6Address compressSidStart = null;
        Ip6Address compressSidNext = null;
        int commonPrefixLength = 0;
        int gsidLength = 0;
        int argLength = 0;
        int index = 0;

        /*Unified conversion to Sid information that needs to be compressed*/
        if (isSid) {
            sidListSrc = segmentList;
        } else {
            sidListSrc = Lists.newArrayList();
            for (int i = 0; i < segmentList.size(); i++) {
                sidListSrc.add(addrToSid(segmentList.get(i)));
            }
        }
        /*Constructing compressible segments and compressing*/
        index = 0;
        log.info("souce of segment list:{} ", sidListSrc.size());

        while (index < sidListSrc.size()) {
            singleSegment = Lists.newArrayList();
            compressSidStart = segmentList.get(index);
            commonPrefixLength = compressPerfixLenGet(compressSidStart);
            gsidLength = compressGsidLenGet(compressSidStart);
            argLength = compressArgLenGet(compressSidStart);

            log.info("first prefix compress begin Index:{}", index);

            for (int i = index; i < sidListSrc.size(); i++) {
                log.info("next prefix compress begin Index:{}", i);
                compressSidNext = segmentList.get(i);
                /*The nodes are incompressible, and they are pressed directly
                into the compression results without any processing*/
                if (!nodeGSrv6Ability(compressSidNext)) {
                    singleCompressSegment = singleSegmentCompress(
                            singleSegment, commonPrefixLength,
                            gsidLength, argLength);
                    gsidList.addAll(singleCompressSegment);
                    gsidList.add(compressSidNext);
                    index = i + 1;
                    break;
                }
                /*Find the prefix matching, put it into the same compression
                segment for compression,find the first mismatched and start
                compression directly*/
                if (gsidPerfixMatch(compressSidStart, compressSidNext, commonPrefixLength)) {
                    singleSegment.add(addrToSid(compressSidNext));
                    if (i == sidListSrc.size() - 1) {
                        singleCompressSegment = singleSegmentCompress(
                                singleSegment, commonPrefixLength,
                                gsidLength, argLength);
                        log.info("SingleCompress size: {}", singleCompressSegment.size());
                        gsidList.addAll(singleCompressSegment);
                        index = sidListSrc.size();
                        break;
                    }
                } else {
                    log.info("prefix mismatch");
                    singleCompressSegment = singleSegmentCompress(
                            singleSegment, commonPrefixLength,
                            gsidLength, argLength);
                    log.info("SingleCompressed size: {}", singleCompressSegment.size());
                    gsidList.addAll(singleCompressSegment);
                    index = i;
                    break;
                }
            }
        }
        log.info("gsrv6 size::{}", gsidList.size());
        return gsidList;
    }
}
