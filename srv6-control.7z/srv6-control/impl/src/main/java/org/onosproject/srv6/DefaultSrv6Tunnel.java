/*
 * Copyright 2015-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.onosproject.srv6;

import org.onlab.packet.Ip6Address;
import org.onosproject.net.DeviceId;

import java.util.List;
import java.util.Objects;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Default Tunnel class.
 */
public class DefaultSrv6Tunnel implements Srv6Tunnel {

    private final String id;
    private final String deviceName;
    private final DeviceId deviceid;
    private final Ip6Address dstIp;
    private final  List<Ip6Address> sids;
    private Integer nextId;

    /**
     * Creates a Tunnel reference.
     *
     * @param deviceid  Tunnel ID
     * @param tid tunnel id
     * @param dstIp Label stack of the tunnel
     * @param sids sid in ipv6
     */
    public DefaultSrv6Tunnel(DeviceId deviceid, String tid, Ip6Address dstIp, List<Ip6Address> sids) {
        this.id = checkNotNull(tid);
        this.dstIp = dstIp;
        this.sids = sids;
        this.deviceid = deviceid;
        this.deviceName = "";

     }

    public DefaultSrv6Tunnel(String deviceName, String tid, Ip6Address dstIp, List<Ip6Address> sids) {
        this.id = checkNotNull(tid);
        this.dstIp = dstIp;
        this.sids = sids;
        this.deviceid  = DeviceId.deviceId("");
        this.deviceName = deviceName;

    }

    /**
     * Creates a new DefaultTunnel reference using the tunnel reference.
     *
     * @param tunnel DefaultTunnel reference
     */
    public DefaultSrv6Tunnel(DefaultSrv6Tunnel tunnel) {
        this.id = tunnel.id;
        this.deviceid = tunnel.deviceid;
        this.dstIp = tunnel.dstIp;
        this.sids = tunnel.sids;
        this.nextId = tunnel.nextId;
        this.deviceName  = tunnel.deviceName;


    }

    @Override
    public String id() {
        return this.id;
    }

    @Override
    public DeviceId deviceid() {
        return this.deviceid;
    }

    @Override
    public String deviceName() {
        return this.deviceName;
    }

    @Override
    public Ip6Address dstIp() {
        return this.dstIp;
    }

    @Override
    public Integer nextId() {
        return this.nextId;
    }

    @Override
    public List<Ip6Address> sids() {
        return this.sids;
    }

    @Override
    public void setNextId(int id) {
        this.nextId = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o instanceof DefaultSrv6Tunnel) {
            DefaultSrv6Tunnel tunnel = (DefaultSrv6Tunnel) o;
            // We compare only the tunnel paths.
            if ((tunnel.id.equals(this.id)) && (tunnel.deviceid.equals(this.deviceid))) {
                return true;
            }
        }

        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id.hashCode(), deviceid.hashCode());
    }

}
