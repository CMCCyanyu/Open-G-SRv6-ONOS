/*
 * Copyright 2015-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.onosproject.srv6;

import org.onlab.packet.Ethernet;
import org.onlab.packet.Ip6Address;
import org.onlab.packet.IpAddress;
import org.onlab.packet.IpPrefix;
import org.onosproject.core.ApplicationId;
import org.onosproject.net.DeviceId;
import org.onosproject.net.flow.DefaultTrafficSelector;
import org.onosproject.net.flow.DefaultTrafficTreatment;
import org.onosproject.net.flow.TrafficSelector;
import org.onosproject.net.flow.TrafficTreatment;
import org.onosproject.net.flowobjective.DefaultForwardingObjective;
import org.onosproject.net.flowobjective.FlowObjectiveService;
import org.onosproject.net.flowobjective.ForwardingObjective;
import org.onosproject.srv6.config.DeviceConfigNotFoundException;
import org.onosproject.store.service.EventuallyConsistentMap;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.onlab.packet.IpAddress.Version.INET6;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Tunnel Handler.
 */
public class Srv6TunnelHander {
    private static final Logger log = getLogger(Srv6TunnelHander.class);

    private ApplicationId appId;
    private DeviceConfiguration deviceConfiguration;
    private FlowObjectiveService flowObjectiveService;
    private Srv6Manager srManager;


    private final EventuallyConsistentMap<String, Srv6Tunnel> srv6TunnelStore;
    private Map<DeviceId, Srv6NextobjHander> srv6NextObjHandlerMap;


    /**
     * Result of tunnel creation or removal.
     */
    public enum Result {
        /**
         * Success.
         */
        SUCCESS,

        /**
         * More than one router needs to specified to created a tunnel.
         */
        WRONG_PATH,

        /**
         * The same tunnel exists already.
         */
        TUNNEL_EXISTS,

        /**
         * The same tunnel ID exists already.
         */
        ID_EXISTS,

        /**
         * Tunnel not found.
         */
        TUNNEL_NOT_FOUND,

        /**
         * Cannot remove the tunnel used by a policy.
         */
        TUNNEL_IN_USE,

        /**
         * Failed to create/remove groups for the tunnel.
         */
        INTERNAL_ERROR
    }

    /**
     * Constructs tunnel handler.
     *
     * @param appId link service
     * @param deviceConfiguration device configuration
     * @param flowObjectiveService group handler map
     * @param srv6NextObjHandlerMap tunnel next obj hand
     * @param srv6TunnelStore tunnel store
     * @param srManager tunnel store
     */
    public Srv6TunnelHander(ApplicationId appId,
                            DeviceConfiguration deviceConfiguration,
                            FlowObjectiveService flowObjectiveService,
                            Map<DeviceId, Srv6NextobjHander> srv6NextObjHandlerMap,
                            EventuallyConsistentMap<String, Srv6Tunnel> srv6TunnelStore,
                            Srv6Manager srManager) {

        this.appId = appId;
        this.deviceConfiguration = deviceConfiguration;
        this.flowObjectiveService = flowObjectiveService;
        this.srv6NextObjHandlerMap = srv6NextObjHandlerMap;
        this.srv6TunnelStore = srv6TunnelStore;
        this.srManager = srManager;
    }

    /**
     * Creates a tunnel.
     *
     * @param srv6Tunnel tunnel reference to create a tunnel
     * @return WRONG_PATH if the tunnel path is wrong, ID_EXISTS if the tunnel ID
     * exists already, TUNNEL_EXISTS if the same tunnel exists, INTERNAL_ERROR
     * if the tunnel creation failed internally, SUCCESS if the tunnel is created
     * successfully
     */
    public Result createSrv6Tunnel(Srv6Tunnel srv6Tunnel) {
        log.info("createSrv6Tunnel srv6Tunnel[{}]", srv6Tunnel.toString());

        if (srv6Tunnel.sids().isEmpty() || srv6Tunnel.sids().size() < 2 || srv6Tunnel.sids().size() > 5) {
            log.error("More than one router needs to specified to created a srv6Tunnel");
            return Result.WRONG_PATH;
        }

        if (srv6TunnelStore.containsKey(srv6Tunnel.id())) {
            log.warn("The same srv6Tunnel ID exists already");
            return Result.ID_EXISTS;
        }

        if (srv6TunnelStore.containsValue(srv6Tunnel)) {
            log.warn("The same srv6Tunnel exists already");
            return Result.TUNNEL_EXISTS;
        }
        TrafficSelector tunnelSelc = buildSelector(srv6Tunnel);
        if (tunnelSelc == null) {
            log.warn("The tunnelSelc create fail");
            return Result.INTERNAL_ERROR;
        }

        List<IpAddress> sidnew = srv6Tunnel.sids().stream()
                .map(e -> IpAddress.valueOf(INET6, e.toOctets()))
                .collect(Collectors.toList());
        TrafficTreatment.Builder tBuilder = DefaultTrafficTreatment
                .builder();
        tBuilder.setSrv6SidList(sidnew);

        ForwardingObjective.Builder fwdBuilder = DefaultForwardingObjective
                .builder()
                .fromApp(appId)
                .makePermanent()
                .withTreatment(tBuilder.build())
                .withPriority(0)
                .withSelector(tunnelSelc)
                .withFlag(ForwardingObjective.Flag.SPECIFIC);

        log.info("createSrv6Tunnel send forward tunnelSelc[{}]", tunnelSelc.toString());
        flowObjectiveService.forward(srv6Tunnel.deviceid(), fwdBuilder.add());

        srv6TunnelStore.put(srv6Tunnel.id(), srv6Tunnel);

        return Result.SUCCESS;
    }

    /**
     * Removes the srv6Tunnel with the srv6Tunnel ID given.
     *
     * @param tunnelInfo srv6Tunnel information to delete tunnels
     * @return TUNNEL_NOT_FOUND if the srv6Tunnel to remove does not exists,
     * INTERNAL_ERROR if the srv6Tunnel creation failed internally, SUCCESS
     * if the srv6Tunnel is created successfully.
     */
    public Result removeSrv6Tunnel(Srv6Tunnel tunnelInfo) {
        Srv6Tunnel srv6Tunnel = srv6TunnelStore.get(tunnelInfo.id());
        if (srv6Tunnel != null) {
            TrafficSelector tunnelSelc = buildSelector(srv6Tunnel);
            if (tunnelSelc == null) {
                log.warn("The tunnelSelc create fail");
                return Result.INTERNAL_ERROR;
            }

            List<IpAddress> sidnew = srv6Tunnel.sids().stream()
                    .map(e -> IpAddress.valueOf(INET6, e.toOctets()))
                    .collect(Collectors.toList());
            TrafficTreatment.Builder tBuilder = DefaultTrafficTreatment
                    .builder();
            tBuilder.setSrv6SidList(sidnew);

            ForwardingObjective.Builder fwdBuilder = DefaultForwardingObjective
                    .builder()
                    .fromApp(appId)
                    .makePermanent()
                    .withSelector(tunnelSelc)
                    .withPriority(0)
                    .withTreatment(tBuilder.build())
                    .withFlag(ForwardingObjective.Flag.SPECIFIC);

            log.info("removeSrv6Tunnel send forward tunnelSelc[{}]", tunnelSelc.toString());
            flowObjectiveService.forward(tunnelInfo.deviceid(), fwdBuilder.remove());

            srv6TunnelStore.remove(srv6Tunnel.id());
        } else {
            log.error("No srv6Tunnel found for srv6Tunnel ID {}", tunnelInfo.id());
            return Result.TUNNEL_NOT_FOUND;
        }

        return Result.SUCCESS;
    }

    /**
     * Returns the srv6Tunnel with the srv6Tunnel ID given.
     *
     * @param tid Tunnel ID
     * @return Tunnel reference
     */
    public Srv6Tunnel getSrv6Tunnel(String tid) {
        return srv6TunnelStore.get(tid);
    }

    /**
     * Returns all tunnels.
     *
     * @return list of Tunnels
     */
    public List<Srv6Tunnel> getSrv6Tunnels() {
        List<Srv6Tunnel> tunnels = new ArrayList<>();
        srv6TunnelStore.values().forEach(srv6Tunnel -> tunnels.add(
                new DefaultSrv6Tunnel((DefaultSrv6Tunnel) srv6Tunnel)));

        return tunnels;
    }

    private TrafficSelector buildSelector(Srv6Tunnel srv6Tunnel) {
        TrafficSelector.Builder tsb = DefaultTrafficSelector.builder();
        tsb.matchEthType(Ethernet.TYPE_IPV6);
        tsb.matchTunnelId((long) Long.valueOf(srv6Tunnel.id()));

        if (srv6Tunnel.dstIp() != null && !srv6Tunnel.dstIp().isZero()) {
            IpPrefix ipPrefix = srv6Tunnel.dstIp().toIpPrefix();
            tsb.matchSrv6DstSid(ipPrefix);
        }
        return tsb.build();
    }

    private TrafficSelector.Builder srv6CocSelcBuild(Srv6Tunnel srv6Tunnel) {
        TrafficSelector.Builder tsb = DefaultTrafficSelector.builder();
        tsb.matchEthType(Ethernet.TYPE_IPV6);
        tsb.matchTunnelId((long) Long.valueOf(srv6Tunnel.id()));

        if (srv6Tunnel.dstIp() != null && !srv6Tunnel.dstIp().isZero()) {
            IpPrefix ipPrefix = srv6Tunnel.dstIp().toIpPrefix();
            tsb.matchSrv6DstSid(ipPrefix);
        }
        return tsb;
    }

    private TrafficTreatment buildTreatment(Srv6Tunnel srv6Tunnel) {

        TrafficTreatment.Builder treatment = DefaultTrafficTreatment.builder();

        if (!srv6Tunnel.sids().isEmpty() && !srv6Tunnel.sids().get(0).isZero()) {
            treatment.pushSRH();
            List<IpAddress> sidnew = srv6Tunnel.sids().stream()
                                     .map(e -> IpAddress.valueOf(INET6, e.toOctets()))
                                     .collect(Collectors.toList());
            treatment.setSrv6SidList(sidnew);
        }
        return treatment.build();
    }

    private boolean isIpv6Configured(DeviceId deviceId) {
        boolean isIpv6Configured;
        try {
            isIpv6Configured = (deviceConfiguration.getSrv6SidEnd(deviceId) != null);
        } catch (DeviceConfigNotFoundException e) {
            isIpv6Configured = false;
        }
        return isIpv6Configured;
    }

    /**
     * Creates a tunnel.
     *
     * @param deviceId tunnel reference to create a tunnel
     * @return WRONG_PATH if the tunnel path is wrong, ID_EXISTS if the tunnel ID
     * exists already, TUNNEL_EXISTS if the same tunnel exists, INTERNAL_ERROR
     * if the tunnel creation failed internally, SUCCESS if the tunnel is created
     * successfully
     */
    public Result srv6RoutePopulator(DeviceId deviceId) {
        log.info("srv6RoutePopulator deviceId[{}]", deviceId.toString());
        Ip6Address srv6SidEnd;

        if (!isIpv6Configured(deviceId)) {
            return Result.INTERNAL_ERROR;
        }
        try {
            srv6SidEnd = deviceConfiguration.getSrv6SidEnd(deviceId);
        } catch (DeviceConfigNotFoundException e) {
            log.warn(e.getMessage() + " ipv6 sid get error");
            return Result.INTERNAL_ERROR;
        }

        srv6RouteTrans(deviceId, srv6SidEnd);
        srv6RouteCocTrans(deviceId, srv6SidEnd);
        return Result.SUCCESS;
    }

    public Result srv6RouteTrans(DeviceId deviceId, Ip6Address nodeSid) {
        log.info("srv6RouteTrans deviceId[{}] nodeSid[{}]",
                 deviceId.toString(), nodeSid.toString());

        Srv6Tunnel srv6Tunnel = new DefaultSrv6Tunnel(deviceId, "0", nodeSid, null);

        TrafficSelector srv6RoutSelc = buildSelector(srv6Tunnel);
        if (srv6RoutSelc == null) {
            log.warn("srv6RouteTrans srv6RoutSelc create fail");
            return Result.INTERNAL_ERROR;
        }

        TrafficTreatment.Builder tBuilder = DefaultTrafficTreatment
                .builder()
                .pushSRH();

        ForwardingObjective.Builder fwdBuilder = DefaultForwardingObjective
                .builder()
                .fromApp(appId)
                .makePermanent()
                .withTreatment(tBuilder.build())
                .withPriority(0)
                .withSelector(srv6RoutSelc)
                .withFlag(ForwardingObjective.Flag.SPECIFIC);

        log.info("srv6RouteTrans send forward tunnelSelc[{}, tBuilder[{}]]",
                 srv6RoutSelc.toString(), tBuilder.toString());
        flowObjectiveService.forward(srv6Tunnel.deviceid(), fwdBuilder.add());

        return Result.SUCCESS;
    }

    public Result srv6RouteCocTrans(DeviceId deviceId, Ip6Address nodeSid) {
        log.info("srv6RouteCocTrans deviceId[{}] nodeSid[{}]",
                 deviceId.toString(), nodeSid.toString());

        for (byte si = 0; si < 4; si++) {
            byte[] addrArry = nodeSid.toOctets();
            addrArry[addrArry.length - 1 - 8] |= (byte) 0x01; //COC bit set
            addrArry[addrArry.length - 1] |= (byte) si;  //si bit set

            Ip6Address nodeSidnew = Ip6Address.valueOf(addrArry);
            Srv6Tunnel srv6Tunnel = new DefaultSrv6Tunnel(deviceId, "0", nodeSidnew, null);
            TrafficSelector.Builder srv6SelcBuild = srv6CocSelcBuild(srv6Tunnel);
            if (srv6SelcBuild == null) {
                log.warn("srv6RouteCocTrans srv6RoutSelc create fail");
                return Result.INTERNAL_ERROR;
            }
            srv6SelcBuild.matchIPv6ExthdrFlags((short) si);

            IpAddress sidnew = IpAddress.valueOf(INET6, addrArry);
            TrafficTreatment.Builder tBuilder = DefaultTrafficTreatment
                    .builder()
                    .pushSRH()
                    .setIpv6Dst(sidnew);

            ForwardingObjective.Builder fwdBuilder = DefaultForwardingObjective
                    .builder()
                    .fromApp(appId)
                    .makePermanent()
                    .withTreatment(tBuilder.build())
                    .withPriority(0)
                    .withSelector(srv6SelcBuild.build())
                    .withFlag(ForwardingObjective.Flag.SPECIFIC);

            log.info("srv6RouteCocTrans send forward tunnelSelc[{}, tBuilder[{}]]",
                     srv6SelcBuild.build().toString(), tBuilder.build().toString());
            flowObjectiveService.forward(srv6Tunnel.deviceid(), fwdBuilder.add());
        }
        return Result.SUCCESS;
    }
}
