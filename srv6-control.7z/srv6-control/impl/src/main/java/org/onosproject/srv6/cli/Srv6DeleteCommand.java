/*
 * Copyright 2015-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.onosproject.srv6.cli;

import org.apache.karaf.shell.api.action.Argument;
import org.apache.karaf.shell.api.action.Command;
import org.apache.karaf.shell.api.action.Completion;
import org.apache.karaf.shell.api.action.lifecycle.Service;
import org.onosproject.cli.AbstractShellCommand;
import org.onosproject.cli.net.DeviceIdCompleter;
import org.onosproject.net.Device;
import org.onosproject.net.DeviceId;
import org.onosproject.net.device.DeviceService;
import org.onosproject.srv6.DefaultSrv6Tunnel;
import org.onosproject.srv6.Srv6Service;
import org.onosproject.srv6.Srv6Tunnel;
import org.onosproject.srv6.Srv6TunnelHander;

/**
 * Command to delete a srv6 tunnel.
 */
@Service
@Command(scope = "onos", name = "srv6-delete",
        description = "Delete a SRv6-TE ")
public class Srv6DeleteCommand extends AbstractShellCommand {

    @Argument(index = 0, name = "uri", description = "Device ID",
            required = true, multiValued = false)
    @Completion(DeviceIdCompleter.class)
    String uri = null;

    @Argument(index = 1, name = "tunnel ID",
            description = "tunnel ID",
            required = true, multiValued = false)
    String tunnelId;

    @Override
    protected void doExecute() {

        Srv6Service srService =
                AbstractShellCommand.get(Srv6Service.class);

        DeviceService deviceService = AbstractShellCommand.get(DeviceService.class);
        Device device = deviceService.getDevice(DeviceId.deviceId(uri));
        if (device == null) {
            print("Device \"%s\" is not found", uri);
            return;
        }

        if (tunnelId.compareTo("0") == 0) {
            print("tunnel id 0 invalid");
            return;
        }
        Srv6Tunnel srv6Tunnel = new DefaultSrv6Tunnel(device.id(), tunnelId, null, null);
        Srv6TunnelHander.Result result = srService.removeSrv6Tunnel(srv6Tunnel);

        switch (result) {
           case INTERNAL_ERROR:
                error("srv6 tunnel delete Err");
                break;
            default:
                break;
        }

    }
}
